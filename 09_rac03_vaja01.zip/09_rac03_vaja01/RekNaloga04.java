class RekNaloga04{
   static void def10(int a){ 
     if (a + 12 == 10) System.out.println(10);
   }
}
