public class RekNaloga05{
   public static int def10(int a){ 
     a = a + 12 ;
     return a;
   }
}
