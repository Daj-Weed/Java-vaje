class RekNaloga05{
   static void def10(int a){ 
     a = a + 12 ;
     System.out.println(a);
   }
}
