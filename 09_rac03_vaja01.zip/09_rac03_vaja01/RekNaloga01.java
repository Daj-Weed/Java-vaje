public class RekNaloga01 {
   static void abc20() { 
     int a = 20;
     System.out.println(a);
   }
   
   static void abc20(int a) { 
     a = a + 12 ;
     System.out.println(a);
   }
}
