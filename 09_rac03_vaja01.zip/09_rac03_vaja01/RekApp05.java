public class RekApp05 {
   public static void main(String[] args) { 
     System.out.print(RekNaloga05.def10(3)+" ");
     System.out.print(RekNaloga05.def10(10)+" ");
     System.out.print(RekNaloga05.def10(-3)+" ");
   }
}
