public class Knjiznica {
    public int gradToDegrees(int grad) {
        return grad;
    }
}
