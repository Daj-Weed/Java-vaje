public class Naloga4 {
    public static void main (String[] args) {
        int tabela[] = new int[5];
        tabela[0] = 5;
        tabela[1] = 10;
        tabela[2] = 25;
        tabela[3] = 60;
        tabela[4] = 145;
        
        for (int i = tabela.length - 1; i >= 0; i--) {
            int a = 0;
            if (tabela[i] > tabela[i--]) {
                System.out.println(a++);
            }
        }
    }
}
