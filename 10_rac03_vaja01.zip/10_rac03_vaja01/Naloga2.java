public class Naloga2 {
    public static int stevec = 0;
    static void test02() {
        char crka = 'b';
        char[] tabchar = {'a','l','i','b','a','b','a'};
        System.out.println("alibaba ima " + tabchar.length + " crk.");
        System.out.print("... in notri je ");
        presetejCrke(stevec, tabchar, crka);
    }
    
    public static void presetejCrke(int stevec, char[] tabchar, char crka) {
        for (int i = 0; i < tabchar.length; i++)
            if (tabchar[i] == crka)
                stevec++;
        System.out.println(stevec + " " + crka + "-jev");
    }
}
