/**
* alternativa k test02/0 iz naloge 2, skušajte klicati ...
*/
public class Naloga3 {
    public static int stevec = 0;
    static void test03() {
        char[] tabchar = {'m','a','r','t','i','n','k','r','p','a','n'};
        System.out.println("Dana tabela vsebuje " + tabchar.length + " znakov.");
        System.out.print("... in notri je ");
        test03gt(tabchar);
        System.out.println(stevec + " a-jev");
        stevec = 0;
    }
    
    static int test03gt(char[] tabchar) {
        for (int i = 0; i < tabchar.length; i++)
        if (tabchar[i] == 'a')
            stevec++;
        return stevec;
    }
}