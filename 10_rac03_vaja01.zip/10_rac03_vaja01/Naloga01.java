public class Naloga01  {
    public static void test01() {
        int []tabela;
        tabela = new int[10]; // 10 celih števil // prvi je 0 0dmaknjen id začetka; dajmo mu vrednost 122
        int []tabela2 = new int[7];
        tabela2[0] = 1;
        int a = 1;
        for (int i = 0; i < tabela2.length; i++) {
            tabela2[i] = a;
            a++;
        }
        izpisiTabelo(tabela);
        
        System.out.println( tabela[0] );
        
        tabela[0] = 122;
        System.out.println( tabela[0] ); // četrti je 3 odmaknjen od začetka: dajmo mu vrednost 777
        System.out.println( tabela[3] );
        
        tabela[3] = 777;
        System.out.println( tabela[3] ); // oba skupaj, pa še tista dva vmes :
        System.out.println( tabela[0] + " " + tabela[1] + " " + tabela[2] + " " + tabela[3] ); // velikost ..
        System.out.println("velikost tabele je " + tabela.length); //iteracija čez vse el. tabele in izpis
        
        izpisiTabelo(tabela, tabela2);
    }
    
    public static void izpisiTabelo(int []tabela) {
        for (int i = 0; i < tabela.length; i++)
            System.out.print(tabela[i] + " ");
    }
    
    public static void izpisiTabelo(int []tabela, int []tabela2) {
        for (int i = 0; i < tabela.length; i++)
            System.out.print(tabela[i] + " ");
        System.out.println();
        for (int i = 0; i < tabela2.length; i++)
            System.out.print(tabela2[i] + " ");
    }
}